//
//  ViewController.m
//  CalculateHeight
//
//  Created by 赵群涛 on 16/4/20.
//  Copyright © 2016年 愚非愚余. All rights reserved.
//

#import "ViewController.h"
#import "CalculateHeight.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSString *str = @"欧你都弄那你懂穷的去你的去你的钱你打钱呢去年去年去年你你去年去年去年 你去你你年轻哦那请你偶请你哦你穷亲ion群殴in起胸腔内怄气你哦去年胸前熊你哦去年i您胸腔内哦亲胸腔内哦亲哦亲胸腔内哦亲哦亲你不去弄清你哦去年你去你你年轻哦那请你偶请你哦你穷亲ion群殴in起胸腔内怄气你哦去年胸前熊你哦去年i您胸腔内哦亲胸腔内哦亲哦亲胸腔内哦亲哦亲你不去弄清你哦去年";
    
    
    UILabel *label = [[UILabel alloc] init];
    label.textColor = [UIColor redColor];
    label.backgroundColor = [UIColor lightGrayColor];
    label.text = str;
    label.numberOfLines = 0;
    CGFloat h = [CalculateHeight getSpaceLabelHeight:label.text withWidth:300];
    label.frame = CGRectMake(10, 100, 300, h);
    [self.view addSubview:label];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
