//
//  CalculateHeight.h
//  CalculateHeight
//
//  Created by 赵群涛 on 16/4/20.
//  Copyright © 2016年 愚非愚余. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface CalculateHeight : NSObject

+(CGFloat)getSpaceLabelHeight:(NSString*)str  withWidth:(CGFloat)width ;

@end
